package av39079.android.fer.hr;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class CalculusActivity extends AppCompatActivity {

    public static final String EXTRAS_SUM = "sum";

    private TextView tvLabel;

    private Button btnReturn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculus);

        tvLabel = (TextView) findViewById(R.id.tvLabel);
        btnReturn = (Button) findViewById(R.id.btnReturn);

        Bundle mapa = getIntent().getExtras();
        int valA = mapa.getInt(FormActivity.EXTRAS_VALA, 0);
        int valB = mapa.getInt(FormActivity.EXTRAS_VALB, 0);

        final int sum = valA + valB;
        tvLabel.setText("Suma je: " + sum);

        btnReturn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent();
                        i.putExtra(EXTRAS_SUM, sum);
                        setResult(RESULT_OK, i);
                        finish();
                    }
                });


    }


}
