package av39079.android.fer.hr;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class FormActivity extends AppCompatActivity {

    public static final String EXTRAS_VALA = "VALA";

    public static final String EXTRAS_VALB = "VALB";

    private TextView tvSum;

    private EditText etVariableA;

    private EditText etVariableB;

    private Button btnCall;

    private Button btnOpen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_form);

        tvSum = (TextView) findViewById(
                R.id.tvSum);
        etVariableA = (EditText) findViewById(
                R.id.etFirstVariable);
        etVariableB = (EditText) findViewById(
                R.id.etSecondVariable);
        Button btnCalculate = (Button) findViewById(
                R.id.btnCalculate);

        btnCall = (Button) findViewById(R.id.btnCall);
        btnOpen = (Button) findViewById(R.id.btnView);

        btnCalculate.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String varA = etVariableA.getText()
                                .toString();
                        String varB = etVariableB.getText()
                                .toString();

                        int valueA = 0;
                        try {
                            valueA = Integer.parseInt(varA);
                        } catch (Exception e) {

                        }
                        int valueB = 0;
                        try {
                            valueB = Integer.parseInt(varB);
                        } catch (Exception e) {

                        }
                        Intent i = new Intent(
                                FormActivity.this,
                                CalculusActivity.class);

                        i.putExtra(EXTRAS_VALA, valueA);
                        i.putExtra(EXTRAS_VALB, valueB);
                        startActivityForResult(i, 666);

                    }
                });

        btnCall.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(
                                Intent.ACTION_CALL,
                                Uri.parse(
                                        "tel:09912345567"));
                        startActivity(i);
                    }
                });

        btnOpen.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String varA = etVariableA.getText()
                                .toString();
                        String varB = etVariableB.getText()
                                .toString();

                        int valueA = 0;
                        try {
                            valueA = Integer.parseInt(varA);
                        } catch (Exception e) {

                        }
                        int valueB = 0;
                        try {
                            valueB = Integer.parseInt(varB);
                        } catch (Exception e) {

                        }

                        Intent i = new Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse(
                                        "https://www.google.hr/?q="
                                                + valueA
                                                + "%2B"
                                                + valueB));
                        startActivity(i);
                    }
                });

    }

    @Override
    protected void onActivityResult(int requestCode,
            int resultCode, Intent data) {
        if (requestCode == 666 && resultCode == RESULT_OK
                && data != null) {

            int sum = data.getExtras()
                    .getInt(CalculusActivity.EXTRAS_SUM,
                            0);

            tvSum.setText(String.valueOf(sum));
        }
    }
}
